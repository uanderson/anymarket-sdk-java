package br.com.anymarket.sdk.exception;

/**
 * Created by marcio.scharam on 17/03/2016.
 */
public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }
}
