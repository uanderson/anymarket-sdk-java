package br.com.anymarket.sdk;

public class ClientException extends RuntimeException {

    public ClientException(String message) {
        super(message);
    }

}
