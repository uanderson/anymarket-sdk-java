package br.com.anymarket.sdk;

/**
 * Created by marcio.scharam on 29/01/2016.
 */
public interface AnymarketPojo {

    String getPathURI();
}
