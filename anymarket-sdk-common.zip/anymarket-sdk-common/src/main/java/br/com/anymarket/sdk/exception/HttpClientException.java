package br.com.anymarket.sdk.exception;

/**
 * Created by marcio.scharam on 18/03/2016.
 */
public class HttpClientException extends RuntimeException {

    public HttpClientException(String message) {
        super(message);
    }
}
