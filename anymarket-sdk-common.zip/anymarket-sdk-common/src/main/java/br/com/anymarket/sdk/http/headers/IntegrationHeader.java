package br.com.anymarket.sdk.http.headers;

/**
 * Created by marcio.scharam on 18/02/2016.
 */
public interface IntegrationHeader {

    String getKey();

    String getValue();
    
}
